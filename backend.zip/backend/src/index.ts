import { Hono } from "hono";
import { serve } from "@hono/node-server";
import { cors } from "hono/cors";

import auth from "./routes/auth";
import camera from "./routes/camera";
import alert from "./routes/alert";

const app = new Hono();

app.use(
  "*",
  cors({
    origin: "http://localhost:5173",
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowHeaders: ["Content-Type", "Authorization"],
  })
);

app.get("/", (c) => c.text("AI Surveillance Backend Running"));

app.route("/api", auth);
app.route("/api", camera);
app.route("/api", alert);

serve({
  fetch: app.fetch,
  port: 3000,
});

console.log("AI Surveillance Backend Running");