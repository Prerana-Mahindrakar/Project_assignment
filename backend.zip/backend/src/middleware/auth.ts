import { Context, Next } from "hono";
import jwt from "jsonwebtoken";

const SECRET = process.env.JWT_SECRET || "secret";

export async function authMiddleware(
  c: Context,
  next: Next
) {

  const authHeader = c.req.header("Authorization");

  if (!authHeader) {

    return c.json(
      {
        success: false,
        message: "Unauthorized",
      },
      401
    );

  }

  const token = authHeader.split(" ")[1];

  try {

    const payload: any = jwt.verify(token, SECRET);

    c.set("user", payload);

    await next();

  } catch (err) {

    return c.json(
      {
        success: false,
        message: "Invalid Token",
      },
      401
    );

  }

}