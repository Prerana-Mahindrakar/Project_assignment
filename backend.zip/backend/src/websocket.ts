import { WebSocketServer } from "ws";

const wss = new WebSocketServer({
  port: 3002,
});

console.log("WebSocket Server Running on ws://localhost:3002");

wss.on("connection", (ws) => {

  console.log("Client Connected");

  ws.send(
    JSON.stringify({
      type: "CONNECTED",
      message: "Connected Successfully",
    })
  );

  ws.on("message", (message) => {

    console.log(message.toString());

    wss.clients.forEach((client: any) => {

      if (client.readyState === 1) {

        client.send(message.toString());

      }

    });

  });

  ws.on("close", () => {

    console.log("Client Disconnected");

  });

});