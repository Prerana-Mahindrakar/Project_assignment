import sql from "./db";

async function testConnection() {
  try {
    const result = await sql`SELECT NOW()`;
    console.log("✅ Database Connected Successfully!");
    console.log(result);
  } catch (error) {
    console.error("❌ Database Connection Failed!");
    console.error(error);
  } finally {
    await sql.end();
  }
}

testConnection();