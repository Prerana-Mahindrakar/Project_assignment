import { Hono } from "hono";

import { authMiddleware } from "../middleware/auth";

import {
  addCamera,
  getCameras,
  updateCamera,
  deleteCamera,
  startCamera,
  stopCamera,
} from "../controllers/cameraController";

const camera = new Hono();

// Protect all camera routes
camera.use("*", authMiddleware);

// Camera CRUD
camera.post("/camera", addCamera);

camera.get("/camera", getCameras);

camera.put("/camera/:id", updateCamera);

camera.delete("/camera/:id", deleteCamera);

// Camera Processing
camera.post("/camera/:id/start", startCamera);

camera.post("/camera/:id/stop", stopCamera);

export default camera;