import { Hono } from "hono";

import { authMiddleware } from "../middleware/auth";

import {
  createAlert,
  getAlerts,
} from "../controllers/alertController";

const alert = new Hono();

// Protect all alert routes
alert.use("*", authMiddleware);

// Worker creates alerts
alert.post("/alerts", createAlert);

// Dashboard fetches alerts
alert.get("/alerts", getAlerts);

export default alert;