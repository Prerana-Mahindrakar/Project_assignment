import jwt from "jsonwebtoken";
import "dotenv/config";
import sql from "../db";
import bcrypt from "bcrypt";

export const signup = async (c: any) => {
  try {
    const { username, password } = await c.req.json();

    if (!username || !password) {
      return c.json({ message: "Username and Password are required" }, 400);
    }

    const user = await sql`
      SELECT * FROM users WHERE username=${username}
    `;

    if (user.length > 0) {
      return c.json({ message: "User already exists" }, 400);
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await sql`
      INSERT INTO users(username,password)
      VALUES(${username},${hashedPassword})
    `;

    return c.json({
      success: true,
      message: "User Registered Successfully"
    });

  } catch (error) {
    console.log(error);
    return c.json({ message: "Server Error" }, 500);
  }
};
export const login = async (c: any) => {
  try {
    const { username, password } = await c.req.json();

    if (!username || !password) {
      return c.json({ message: "Username and Password are required" }, 400);
    }

    const users = await sql`
      SELECT * FROM users WHERE username = ${username}
    `;

    if (users.length === 0) {
      return c.json({ message: "Invalid username or password" }, 401);
    }

    const user = users[0];

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return c.json({ message: "Invalid username or password" }, 401);
    }

    const token = jwt.sign(
      {
        id: user.id,
        username: user.username,
      },
      process.env.JWT_SECRET!,
      {
        expiresIn: "24h",
      }
    );

    return c.json({
      success: true,
      token,
      user: {
        id: user.id,
        username: user.username,
      },
    });
  } catch (error) {
    console.error(error);
    return c.json({ message: "Server Error" }, 500);
  }
};