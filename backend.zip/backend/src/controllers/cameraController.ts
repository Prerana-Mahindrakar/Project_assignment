import sql from "../db";

export const addCamera = async (c: any) => {
  try {
    const user = c.get("user");

    const { name, rtsp_url, location, enabled } = await c.req.json();

    if (!name || !rtsp_url) {
      return c.json(
        {
          success: false,
          message: "Camera name and RTSP URL are required",
        },
        400
      );
    }

    const result = await sql`
      INSERT INTO cameras
      (
        user_id,
        name,
        rtsp_url,
        location,
        enabled
      )
      VALUES
      (
        ${user.id},
        ${name},
        ${rtsp_url},
        ${location},
        ${enabled ?? true}
      )
      RETURNING *;
    `;

    return c.json({
      success: true,
      camera: result[0],
    });
  } catch (err) {
    console.error(err);

    return c.json(
      {
        success: false,
        message: "Server Error",
      },
      500
    );
  }
};

export const getCameras = async (c: any) => {
  try {
    const user = c.get("user");

    const cameras = await sql`
      SELECT *
      FROM cameras
      WHERE user_id=${user.id}
      ORDER BY id DESC;
    `;

    return c.json({
      success: true,
      cameras,
    });
  } catch (err) {
    console.error(err);

    return c.json(
      {
        success: false,
        message: "Server Error",
      },
      500
    );
  }
};

export const updateCamera = async (c: any) => {
  try {
    const user = c.get("user");

    const id = Number(c.req.param("id"));

    const { name, rtsp_url, location, enabled } =
      await c.req.json();

    const result = await sql`
      UPDATE cameras
      SET
      name=${name},
      rtsp_url=${rtsp_url},
      location=${location},
      enabled=${enabled}
      WHERE
      id=${id}
      AND
      user_id=${user.id}
      RETURNING *;
    `;

    if (result.length === 0) {
      return c.json(
        {
          success: false,
          message: "Camera not found",
        },
        404
      );
    }

    return c.json({
      success: true,
      camera: result[0],
    });
  } catch (err) {
    console.error(err);

    return c.json(
      {
        success: false,
        message: "Server Error",
      },
      500
    );
  }
};

export const deleteCamera = async (c: any) => {
  try {
    const user = c.get("user");

    const id = Number(c.req.param("id"));

    const result = await sql`
      DELETE FROM cameras
      WHERE
      id=${id}
      AND
      user_id=${user.id}
      RETURNING *;
    `;

    if (result.length === 0) {
      return c.json(
        {
          success: false,
          message: "Camera not found",
        },
        404
      );
    }

    return c.json({
      success: true,
      message: "Camera Deleted Successfully",
    });
  } catch (err) {
    console.error(err);

    return c.json(
      {
        success: false,
        message: "Server Error",
      },
      500
    );
  }
};

export const startCamera = async (c: any) => {
  try {
    const id = Number(c.req.param("id"));

    await sql`
      INSERT INTO camera_commands
      (
        camera_id,
        command
      )
      VALUES
      (
        ${id},
        'START'
      );
    `;

    return c.json({
      success: true,
      message: "Start command sent",
    });
  } catch (err) {
    console.error(err);

    return c.json(
      {
        success: false,
        message: "Server Error",
      },
      500
    );
  }
};

export const stopCamera = async (c: any) => {
  try {
    const id = Number(c.req.param("id"));

    await sql`
      INSERT INTO camera_commands
      (
        camera_id,
        command
      )
      VALUES
      (
        ${id},
        'STOP'
      );
    `;

    return c.json({
      success: true,
      message: "Stop command sent",
    });
  } catch (err) {
    console.error(err);

    return c.json(
      {
        success: false,
        message: "Server Error",
      },
      500
    );
  }
};