import sql from "../db";

export const createAlert = async (c: any) => {
  try {
    const {
      camera_id,
      person_count,
      image_url
    } = await c.req.json();

    const result = await sql`
      INSERT INTO alerts
      (
        camera_id,
        person_count,
        image_url
      )
      VALUES
      (
        ${camera_id},
        ${person_count},
        ${image_url}
      )
      RETURNING *;
    `;

    return c.json({
      success: true,
      alert: result[0],
    });

  } catch (err) {
    console.error(err);

    return c.json(
      {
        success: false,
        message: "Server Error",
      },
      500
    );
  }
};

export const getAlerts = async (c: any) => {
  try {

    const page = Number(c.req.query("page") || 1);
    const limit = Number(c.req.query("limit") || 10);

    const offset = (page - 1) * limit;

    const camera = c.req.query("camera");

    const from = c.req.query("from");

    const to = c.req.query("to");

    let alerts;

    if (camera && from && to) {

      alerts = await sql`
        SELECT *
        FROM alerts
        WHERE
        camera_id=${Number(camera)}
        AND
        event_time BETWEEN ${from} AND ${to}
        ORDER BY event_time DESC
        LIMIT ${limit}
        OFFSET ${offset};
      `;

    } else if (camera) {

      alerts = await sql`
        SELECT *
        FROM alerts
        WHERE camera_id=${Number(camera)}
        ORDER BY event_time DESC
        LIMIT ${limit}
        OFFSET ${offset};
      `;

    } else {

      alerts = await sql`
        SELECT *
        FROM alerts
        ORDER BY event_time DESC
        LIMIT ${limit}
        OFFSET ${offset};
      `;

    }

    return c.json({

      success: true,

      page,

      limit,

      total: alerts.length,

      alerts,

    });

  } catch (err) {

    console.error(err);

    return c.json(
      {
        success: false,
        message: "Server Error",
      },
      500
    );
  }
};