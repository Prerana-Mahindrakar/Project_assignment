import { useState } from "react";

interface Props {
  onCameraAdded: () => void;
}

export default function CameraForm({ onCameraAdded }: Props) {
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [rtsp, setRtsp] = useState("");

  const token = localStorage.getItem("token");

  async function addCamera(e: React.FormEvent) {
    e.preventDefault();

    try {
      const res = await fetch(
        "http://localhost:3000/api/camera",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name,
            location,
            rtsp_url: rtsp,
            enabled: true,
          }),
        }
      );

      const data = await res.json();

      if (data.success) {
        alert("Camera Added Successfully");

        setName("");
        setLocation("");
        setRtsp("");

        onCameraAdded();
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.log(err);
      alert("Server Error");
    }
  }

  return (
    <form
      onSubmit={addCamera}
      style={{
        background: "#fff",
        padding: "20px",
        borderRadius: "10px",
        marginBottom: "20px",
        boxShadow: "0 2px 8px rgba(0,0,0,.15)",
      }}
    >
      <h2>Add Camera</h2>

      <input
        type="text"
        placeholder="Camera Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
        style={{
          width: "100%",
          padding: "10px",
          marginBottom: "10px",
        }}
      />

      <input
        type="text"
        placeholder="Location"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        required
        style={{
          width: "100%",
          padding: "10px",
          marginBottom: "10px",
        }}
      />

      <input
        type="text"
        placeholder="RTSP URL"
        value={rtsp}
        onChange={(e) => setRtsp(e.target.value)}
        required
        style={{
          width: "100%",
          padding: "10px",
          marginBottom: "10px",
        }}
      />

      <button
        type="submit"
        style={{
          padding: "10px 20px",
          background: "#2563eb",
          color: "white",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Add Camera
      </button>
    </form>
  );
}