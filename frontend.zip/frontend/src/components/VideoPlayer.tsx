import { useEffect, useRef } from "react";

type Props = {
  workerUrl?: string;
};

export default function VideoPlayer({
  workerUrl = "http://localhost:8080/offer",
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let pc: RTCPeerConnection;

    async function start() {
      try {
        pc = new RTCPeerConnection();

        pc.ontrack = (event) => {
          console.log("Video received");

          if (videoRef.current) {
            videoRef.current.srcObject = event.streams[0];
          }
        };

        pc.onconnectionstatechange = () => {
          console.log("Connection:", pc.connectionState);
        };

        pc.addTransceiver("video", {
          direction: "recvonly",
        });

        const offer = await pc.createOffer();

        await pc.setLocalDescription(offer);

        await new Promise<void>((resolve) => {
          if (pc.iceGatheringState === "complete") {
            resolve();
          } else {
            const check = () => {
              if (pc.iceGatheringState === "complete") {
                pc.removeEventListener(
                  "icegatheringstatechange",
                  check
                );
                resolve();
              }
            };

            pc.addEventListener(
              "icegatheringstatechange",
              check
            );
          }
        });

        const response = await fetch(workerUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            sdp: pc.localDescription?.sdp,
            type: pc.localDescription?.type,
          }),
        });

        const answer = await response.json();

        await pc.setRemoteDescription(answer);
      } catch (err) {
        console.error(err);
      }
    }

    start();

    return () => {
      if (pc) {
        pc.close();
      }
    };
  }, [workerUrl]);

  return (
    <video
      ref={videoRef}
      autoPlay
      playsInline
      muted
      controls={false}
      style={{
        width: "100%",
        background: "#000",
        borderRadius: "10px",
      }}
    />
  );
}