import VideoPlayer from "./VideoPlayer";

interface Camera {
  id: number;
  name: string;
  location: string;
  enabled: boolean;
}

interface Props {
  camera: Camera;
  onStart: (id: number) => void;
  onStop: (id: number) => void;
}

export default function CameraCard({
  camera,
  onStart,
  onStop,
}: Props) {
  return (
    <div
      style={{
        background: "#ffffff",
        borderRadius: "10px",
        padding: "15px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
      }}
    >
      <h2>{camera.name}</h2>

      <p>
        <strong>Location:</strong> {camera.location}
      </p>

      <p>
        <strong>Status:</strong>{" "}
        <span
          style={{
            color: camera.enabled ? "green" : "red",
            fontWeight: "bold",
          }}
        >
          {camera.enabled ? "Live" : "Stopped"}
        </span>
      </p>

      <VideoPlayer />

      <div
        style={{
          marginTop: "15px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <button
          onClick={() => onStart(camera.id)}
          style={{
            padding: "8px 18px",
            background: "#16a34a",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          ▶ Start
        </button>

        <button
          onClick={() => onStop(camera.id)}
          style={{
            padding: "8px 18px",
            background: "#dc2626",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          ■ Stop
        </button>
      </div>

      <div
        style={{
          marginTop: "15px",
          padding: "10px",
          background: "#f3f4f6",
          borderRadius: "5px",
        }}
      >
        <p>
          <strong>Persons Detected:</strong> Live from Worker
        </p>

        <p>
          <strong>FPS:</strong> Live
        </p>

        <p>
          <strong>Connection:</strong>{" "}
          {camera.enabled ? "Connected" : "Disconnected"}
        </p>
      </div>
    </div>
  );
}