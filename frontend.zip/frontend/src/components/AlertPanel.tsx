import { useEffect, useState } from "react";

interface Alert {
  id: number;
  camera_id: number;
  person_count: number;
  event_time: string;
}

export default function AlertPanel() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  const token = localStorage.getItem("token");

  useEffect(() => {
    loadAlerts();

    const socket = new WebSocket("ws://localhost:3002");

    socket.onmessage = () => {
      loadAlerts();
    };

    return () => socket.close();
  }, []);

  async function loadAlerts() {
    try {
      const res = await fetch(
        "http://localhost:3000/api/alerts?page=1&limit=10",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await res.json();

      setAlerts(data.alerts || []);
    } catch (err) {
      console.log(err);
    }
  }

  return (
    <div
      style={{
        marginTop: 20,
        border: "1px solid #ddd",
        borderRadius: 8,
        padding: 15,
      }}
    >
      <h2>Recent Alerts</h2>

      {alerts.length === 0 ? (
        <p>No Alerts</p>
      ) : (
        alerts.map((alert) => (
          <div
            key={alert.id}
            style={{
              borderBottom: "1px solid #eee",
              padding: "10px 0",
            }}
          >
            <strong>Camera {alert.camera_id}</strong>

            <br />

            Persons Detected : {alert.person_count}

            <br />

            {new Date(alert.event_time).toLocaleString()}
          </div>
        ))
      )}
    </div>
  );
}