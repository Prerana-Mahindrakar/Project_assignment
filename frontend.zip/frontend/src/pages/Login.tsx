import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  const [isLogin, setIsLogin] = useState(true);

  const [username, setUsername] = useState("");

  const [password, setPassword] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();

    const url = isLogin
      ? "http://localhost:3000/api/login"
      : "http://localhost:3000/api/signup";

    try {
      const res = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username,
          password,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.message);
        return;
      }

      if (isLogin) {
        localStorage.setItem("token", data.token);

        navigate("/dashboard");
      } else {
        alert("Registration Successful");

        setIsLogin(true);
      }
    } catch (err) {
      console.log(err);
      alert("Server Error");
    }
  }

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
      }}
    >
      <form
        onSubmit={submit}
        style={{
          width: "350px",
          border: "1px solid #ccc",
          padding: "20px",
        }}
      >
        <h2>{isLogin ? "Login" : "Register"}</h2>

        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
          style={{
            width: "100%",
            padding: "10px",
            marginBottom: "10px",
          }}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{
            width: "100%",
            padding: "10px",
            marginBottom: "15px",
          }}
        />

        <button
          type="submit"
          style={{
            width: "100%",
            padding: "10px",
          }}
        >
          {isLogin ? "Login" : "Register"}
        </button>

        <br />
        <br />

        <button
          type="button"
          onClick={() => setIsLogin(!isLogin)}
          style={{
            width: "100%",
            padding: "10px",
          }}
        >
          {isLogin
            ? "Create New Account"
            : "Already have an account?"}
        </button>
      </form>
    </div>
  );
}