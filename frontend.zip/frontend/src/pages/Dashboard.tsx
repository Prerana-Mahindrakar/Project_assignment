import { useEffect, useState } from "react";

import Navbar from "../components/Navbar";
import CameraForm from "../components/CameraForm";
import CameraCard from "../components/CameraCard";
import AlertPanel from "../components/AlertPanel";

type Camera = {
  id: number;
  name: string;
  location: string;
  enabled: boolean;
};

export default function Dashboard() {
  const [cameras, setCameras] = useState<Camera[]>([]);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token");

  useEffect(() => {
    loadCameras();
  }, []);

  async function loadCameras() {
    try {
      const res = await fetch("http://localhost:3000/api/camera", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();

      setCameras(data.cameras || []);
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  }

  async function sendCommand(
    id: number,
    action: "start" | "stop"
  ) {
    try {
      await fetch(
        `http://localhost:3000/api/camera/${id}/${action}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      loadCameras();
    } catch (err) {
      console.log(err);
    }
  }

  if (loading) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Loading Cameras...</h2>
      </div>
    );
  }

  return (
    <div
      style={{
        background: "#f5f5f5",
        minHeight: "100vh",
      }}
    >
      <Navbar />

      <div
        style={{
          padding: "20px",
        }}
      >
        <CameraForm onCameraAdded={loadCameras} />

        {cameras.length === 0 ? (
          <h2>No Cameras Added</h2>
        ) : (
          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fill,minmax(420px,1fr))",
              gap: "20px",
            }}
          >
            {cameras.map((camera) => (
              <CameraCard
                key={camera.id}
                camera={camera}
                onStart={(id) => sendCommand(id, "start")}
                onStop={(id) => sendCommand(id, "stop")}
              />
            ))}
          </div>
        )}

        <AlertPanel />
      </div>
    </div>
  );
}