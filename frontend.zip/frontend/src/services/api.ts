const BASE_URL = "http://localhost:3000/api";

function getToken() {
  return localStorage.getItem("token");
}

export async function signup(
  username: string,
  password: string
) {
  const res = await fetch(`${BASE_URL}/signup`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      username,
      password,
    }),
  });

  return res.json();
}

export async function login(
  username: string,
  password: string
) {
  const res = await fetch(`${BASE_URL}/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      username,
      password,
    }),
  });

  return res.json();
}

export async function getCameras() {
  const res = await fetch(`${BASE_URL}/camera`, {
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  });

  return res.json();
}

export async function addCamera(camera: {
  name: string;
  location: string;
  rtsp_url: string;
}) {
  const res = await fetch(`${BASE_URL}/camera`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
    body: JSON.stringify({
      ...camera,
      enabled: true,
    }),
  });

  return res.json();
}

export async function startCamera(id: number) {
  const res = await fetch(
    `${BASE_URL}/camera/${id}/start`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${getToken()}`,
      },
    }
  );

  return res.json();
}

export async function stopCamera(id: number) {
  const res = await fetch(
    `${BASE_URL}/camera/${id}/stop`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${getToken()}`,
      },
    }
  );

  return res.json();
}

export async function getAlerts() {
  const res = await fetch(`${BASE_URL}/alerts`, {
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  });

  return res.json();
}